#ifndef _BUILTIN_H_
#define _BUILTIN_H_
#include "type.h"
#include "common.h"

// command* builtin_command;

// #define NUM_COMMAND 

extern struct command command_list[];
extern int num_command;



#endif
