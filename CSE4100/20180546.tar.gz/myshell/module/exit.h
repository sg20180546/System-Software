#ifndef _EXIT_H_
#define _EXIT_H_
#include "../common.h"
#include "../type.h"
#include "../sig.h"
#include "jobs.h"

void exit_();

#endif