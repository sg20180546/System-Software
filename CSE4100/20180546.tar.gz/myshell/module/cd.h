#ifndef _CD_H_
#define _CD_H_
#include "../common.h"
#include "../type.h"
void change_directory(char** argv);
#endif