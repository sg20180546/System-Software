#ifndef _MYSHELL_H_
#define _MYSHELL_H_

#include "common.h"
#include "interperter.h"
#include "builtin.h"
#include "./module/jobs.h"

char cmdline[MAXLINE];



#endif